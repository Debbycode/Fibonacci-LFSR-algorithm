#include <iostream>
#include "FibLFSR.hpp"

int main() {
    PhotoMagic::FibLFSR lfsr("1011011000110110");

    std::cout << "New bit after one step: " << lfsr.step() << std::endl;
    std::cout << "Generated 5 bits: " << lfsr.generate(5) << std::endl;
    std::cout << "Current state of LFSR: " << lfsr << std::endl;

    return 0;
}