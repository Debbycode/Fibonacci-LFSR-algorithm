#include "FibLFSR.hpp"

namespace PhotoMagic {
    FibLFSR::FibLFSR(std::string seed) : register_(seed), tap_(seed.length() - 1) {}

    int FibLFSR::step() {
        int xor_result = (register_[0] - '0') ^ (register_[tap_] - '0');
        int new_bit = register_[0] - '0';
        register_ = register_.substr(1) + std::to_string(xor_result);
        return new_bit;
    }

    int FibLFSR::generate(int k) {
        int result = 0;
        for (int i = 0; i < k; ++i) {
            result = (result << 1) | step();
        }
        return result;
    }

    std::ostream& operator<<(std::ostream& os, const FibLFSR& lfsr) {
        os << lfsr.register_;
        return os;
    }
}