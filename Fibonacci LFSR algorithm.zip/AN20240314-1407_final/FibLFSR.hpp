#ifndef FIBLFSR_HPP
#define FIBLFSR_HPP

#include <string>
#include <iostream>

namespace PhotoMagic {
    class FibLFSR {
    public:
        FibLFSR(std::string seed);
        int step();
        int generate(int k);
        friend std::ostream& operator<<(std::ostream& os, const FibLFSR& lfsr);

    private:
        std::string register_;
        int tap_;
    };
}

#endif
